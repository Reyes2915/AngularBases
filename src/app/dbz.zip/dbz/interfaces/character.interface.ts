export interface Character {
  id?: string;
  name: string;
  power: number;
}
